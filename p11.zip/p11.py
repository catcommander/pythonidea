class Student():
    def __init__(self,name= "None",age= 18):
        name
        age
        print("嗨,我是{0},我今年{1}岁！".format(name,age))
    def say(self):
        print("snake")
def sayhello():
    print("你好呀，又是充满希望的一天！")
if __name__ == "__main__":
    print("一gay,我哩giao")

